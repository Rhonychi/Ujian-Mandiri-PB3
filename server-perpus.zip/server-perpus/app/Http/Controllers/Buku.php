<?php

namespace App\Http\Controllers;

use App\Models\Buku as ModelsBuku;
use Illuminate\Http\Request;

class Buku extends Controller
{
    public function tambahBuku(Request $re)
    {
        try {
            $TambahBuku                     = new ModelsBuku;
            $TambahBuku->nama_buku          = $re->nama_buku;
            $TambahBuku->author             = $re->author;
            $TambahBuku->sinopsis           = $re->sinopsis;
            $TambahBuku->save();

            return response('Buku berhasil disimpan', 200)->header('Content-type', 'text/plain');
        } catch (\Throwable $th) {
            return response('Buku gagal disimpan | ' . $th->getMessage(), 500);
        }
    }
}
