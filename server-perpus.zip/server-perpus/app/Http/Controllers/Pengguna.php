<?php

namespace App\Http\Controllers;

use App\Models\Pengguna as ModelsPengguna;
use Illuminate\Http\Request;

class Pengguna extends Controller
{
    public function tambahPengguna(Request $re)
    {
        try {
            $TambahPengguna                     = new ModelsPengguna();
            $TambahPengguna->username           = $re->username;
            $TambahPengguna->password           = $re->password;
            $TambahPengguna->save();

            return response('Data pengguna berhasil disimpan', 200);
        } catch (\Throwable $th) {
            return response('Data pengguna gagal disimpan | ' . $th->getMessage(), 500);
        }
    }
}
